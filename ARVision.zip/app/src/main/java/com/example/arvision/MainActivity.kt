package com.example.arvision

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.RectF
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.util.Size
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.AspectRatio
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetectorResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

private const val TAG = "ARVision"

/** Roda a detecção de objetos a cada N frames (a mão roda em todos). Economiza CPU. */
private const val OBJ_EVERY = 4

/** Classes que não queremos mostrar (a própria mão costuma virar "person"). */
private val IGNORE = setOf("person")

class MainActivity : ComponentActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var overlay: OverlayView
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()

    @Volatile private var hand: HandLandmarker? = null
    @Volatile private var detector: ObjectDetector? = null
    private var frameCount = 0

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) loadAndStart() else overlay.setStatus("Permissão da câmera negada")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        previewView = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        overlay = OverlayView(this)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        root.addView(previewView, FrameLayout.LayoutParams(mp, mp))
        root.addView(overlay, FrameLayout.LayoutParams(mp, mp))
        setContentView(root)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) loadAndStart() else permLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun loadAndStart() {
        overlay.setStatus("Carregando modelos...")
        Thread {
            try {
                createDetectors()
                runOnUiThread { overlay.setStatus(""); startCamera() }
            } catch (e: Exception) {
                Log.e(TAG, "init", e)
                runOnUiThread { overlay.setStatus("Erro ao carregar modelos: ${e.message}") }
            }
        }.start()
    }

    private fun createDetectors() {
        val handOpts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(1)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setResultListener { r: HandLandmarkerResult, _: MPImage ->
                val lm = r.landmarks().firstOrNull()
                // [polegar x,y, indicador x,y, pulso x,y, base do dedo médio x,y]
                val pts = lm?.let {
                    floatArrayOf(
                        it[4].x(), it[4].y(), it[8].x(), it[8].y(),
                        it[0].x(), it[0].y(), it[9].x(), it[9].y()
                    )
                }
                runOnUiThread { overlay.onHand(pts) }
            }
            .setErrorListener { e -> Log.e(TAG, "hand", e) }
            .build()
        hand = HandLandmarker.createFromOptions(this, handOpts)

        val objOpts = ObjectDetector.ObjectDetectorOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("efficientdet.tflite").build())
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setMaxResults(8)
            .setScoreThreshold(0.35f)
            .setResultListener { r: ObjectDetectorResult, _: MPImage ->
                val list = r.detections().mapNotNull { d ->
                    val c = d.categories().firstOrNull() ?: return@mapNotNull null
                    val name = c.categoryName()
                    if (name in IGNORE) null else Det(RectF(d.boundingBox()), name, c.score())
                }
                runOnUiThread { overlay.onDetections(list) }
            }
            .setErrorListener { e -> Log.e(TAG, "obj", e) }
            .build()
        detector = ObjectDetector.createFromOptions(this, objOpts)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val aspect = AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY

            val preview = Preview.Builder()
                .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(aspect).build())
                .build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }

            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(
                    ResolutionSelector.Builder()
                        .setAspectRatioStrategy(aspect)
                        .setResolutionStrategy(
                            ResolutionStrategy(
                                Size(640, 480),
                                ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                            )
                        ).build()
                )
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(executor) { proxy -> analyze(proxy) }

            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val h = hand ?: return
            val o = detector
            var bmp = proxy.toBitmap()
            val rot = proxy.imageInfo.rotationDegrees
            if (rot != 0) {
                val m = Matrix().apply { postRotate(rot.toFloat()) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, false)
            }
            overlay.frameW = bmp.width
            overlay.frameH = bmp.height

            val ts = SystemClock.uptimeMillis()
            h.detectAsync(BitmapImageBuilder(bmp).build(), ts)
            if (o != null && frameCount++ % OBJ_EVERY == 0) {
                o.detectAsync(BitmapImageBuilder(bmp).build(), ts)
            }
        } catch (e: Exception) {
            Log.e(TAG, "frame", e)
        } finally {
            proxy.close()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        val h = hand; val o = detector
        hand = null; detector = null
        executor.shutdown()
        h?.close(); o?.close()
    }
}
