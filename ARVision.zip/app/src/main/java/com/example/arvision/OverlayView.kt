package com.example.arvision

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import kotlin.math.hypot
import kotlin.math.max

class Det(val box: RectF, val label: String, val score: Float)

object Labels {
    private val pt = mapOf(
        "person" to "pessoa", "bicycle" to "bicicleta", "car" to "carro", "motorcycle" to "moto",
        "airplane" to "avião", "bus" to "ônibus", "train" to "trem", "truck" to "caminhão",
        "boat" to "barco", "traffic light" to "semáforo", "fire hydrant" to "hidrante",
        "stop sign" to "placa de pare", "parking meter" to "parquímetro", "bench" to "banco",
        "bird" to "pássaro", "cat" to "gato", "dog" to "cachorro", "horse" to "cavalo",
        "sheep" to "ovelha", "cow" to "vaca", "elephant" to "elefante", "bear" to "urso",
        "zebra" to "zebra", "giraffe" to "girafa", "backpack" to "mochila",
        "umbrella" to "guarda-chuva", "handbag" to "bolsa", "tie" to "gravata", "suitcase" to "mala",
        "frisbee" to "frisbee", "skis" to "esquis", "snowboard" to "snowboard",
        "sports ball" to "bola", "kite" to "pipa", "baseball bat" to "taco de beisebol",
        "baseball glove" to "luva de beisebol", "skateboard" to "skate",
        "surfboard" to "prancha de surfe", "tennis racket" to "raquete de tênis",
        "bottle" to "garrafa", "wine glass" to "taça", "cup" to "copo", "fork" to "garfo",
        "knife" to "faca", "spoon" to "colher", "bowl" to "tigela", "banana" to "banana",
        "apple" to "maçã", "sandwich" to "sanduíche", "orange" to "laranja", "broccoli" to "brócolis",
        "carrot" to "cenoura", "hot dog" to "cachorro-quente", "pizza" to "pizza",
        "donut" to "rosquinha", "cake" to "bolo", "chair" to "cadeira", "couch" to "sofá",
        "potted plant" to "planta", "bed" to "cama", "dining table" to "mesa", "toilet" to "vaso sanitário",
        "tv" to "TV", "laptop" to "notebook", "mouse" to "mouse", "remote" to "controle remoto",
        "keyboard" to "teclado", "cell phone" to "celular", "microwave" to "micro-ondas",
        "oven" to "forno", "toaster" to "torradeira", "sink" to "pia", "refrigerator" to "geladeira",
        "book" to "livro", "clock" to "relógio", "vase" to "vaso", "scissors" to "tesoura",
        "teddy bear" to "urso de pelúcia", "hair drier" to "secador de cabelo",
        "hair dryer" to "secador de cabelo", "toothbrush" to "escova de dentes"
    )

    fun name(en: String): String =
        (pt[en] ?: en).replaceFirstChar { it.uppercase() }
}

/**
 * Camada de realidade aumentada desenhada por cima da câmera:
 * caixas dos objetos, cursor do dedo, tag ao apontar e cartão ao fazer pinça.
 * Tudo roda na thread principal.
 */
class OverlayView(context: Context) : View(context) {

    @Volatile var frameW = 0
    @Volatile var frameH = 0

    private var status = ""
    private var dets: List<Det> = emptyList()
    private var cursor: PointF? = null
    private var smooth: PointF? = null
    private val history = ArrayDeque<PointF>()
    private var pinching = false
    private var hover: Det? = null
    private var selected: Det? = null
    private var selectedUntil = 0L

    private val d = resources.displayMetrics.density

    private val thin = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2 * d; color = Color.parseColor("#80FFFFFF")
    }
    private val hoverFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.parseColor("#2600E676")
    }
    private val hoverStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5 * d; color = Color.parseColor("#00E676")
    }
    private val selStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 6 * d; color = Color.parseColor("#FFAB00")
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3 * d; color = Color.WHITE
    }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD
    }

    fun setStatus(s: String) { status = s; invalidate() }

    fun onDetections(list: List<Det>) {
        dets = list
        hover = hit(cursor)
        invalidate()
    }

    /** p = [polegar x,y, indicador x,y, pulso x,y, base do dedo médio x,y] normalizados. */
    fun onHand(p: FloatArray?) {
        if (p == null || frameW == 0 || width == 0) {
            cursor = null; smooth = null; pinching = false; hover = null
            history.clear()
            invalidate(); return
        }
        val fw = frameW.toFloat(); val fh = frameH.toFloat()
        fun dist(ax: Float, ay: Float, bx: Float, by: Float) = hypot((ax - bx) * fw, (ay - by) * fh)

        // pinça = distância polegar–indicador relativa ao tamanho da palma (com histerese)
        val ratio = dist(p[0], p[1], p[2], p[3]) / dist(p[4], p[5], p[6], p[7]).coerceAtLeast(1f)
        val nowPinch = if (pinching) ratio < 0.45f else ratio < 0.28f

        val raw = PointF(sx(p[2]), sy(p[3]))          // ponta do indicador = cursor
        val s = smooth
        val sm = if (s == null) raw else PointF(s.x + (raw.x - s.x) * 0.5f, s.y + (raw.y - s.y) * 0.5f)

        if (!nowPinch) {
            smooth = sm
            history.addLast(PointF(sm.x, sm.y))
            if (history.size > 6) history.removeFirst()
            cursor = sm
        } else if (!pinching) {
            // início da pinça: usa a posição de ~150 ms atrás (antes do dedo se mover) e "clica"
            val anchor = history.firstOrNull() ?: sm
            cursor = anchor
            click(anchor)
        }
        pinching = nowPinch
        hover = hit(cursor)
        invalidate()
    }

    private fun click(p: PointF) {
        selected = hit(p)
        selectedUntil = SystemClock.uptimeMillis() + 5000
        postInvalidateDelayed(5100)
    }

    // ---- mapeamento imagem -> tela (PreviewView em FILL_CENTER) ----
    private fun scale() = max(width.toFloat() / frameW, height.toFloat() / frameH)
    private fun sx(nx: Float) = nx * frameW * scale() + (width - frameW * scale()) / 2f
    private fun sy(ny: Float) = ny * frameH * scale() + (height - frameH * scale()) / 2f
    private fun toScreen(r: RectF): RectF {
        val s = scale()
        val ox = (width - frameW * s) / 2f
        val oy = (height - frameH * s) / 2f
        return RectF(r.left * s + ox, r.top * s + oy, r.right * s + ox, r.bottom * s + oy)
    }

    /** Objeto sob o ponto (o menor, se houver caixas sobrepostas). */
    private fun hit(p: PointF?): Det? {
        if (p == null || frameW == 0 || width == 0) return null
        var best: Det? = null
        var bestArea = Float.MAX_VALUE
        for (dt in dets) {
            val r = toScreen(dt.box)
            if (r.contains(p.x, p.y)) {
                val a = r.width() * r.height()
                if (a < bestArea) { bestArea = a; best = dt }
            }
        }
        return best
    }

    private fun pill(c: Canvas, text: String, x: Float, y: Float, bg: Int, size: Float) {
        tp.textSize = size
        val w = tp.measureText(text) + 24 * d
        val h = size + 16 * d
        val left = x.coerceIn(4 * d, max(4 * d, width - w - 4 * d))
        fill.color = bg
        c.drawRoundRect(left, y, left + w, y + h, h / 2, h / 2, fill)
        tp.color = Color.WHITE
        c.drawText(text, left + 12 * d, y + h / 2 + size * 0.35f, tp)
    }

    private fun pct(s: Float) = "${(s * 100).toInt()}%"

    override fun onDraw(c: Canvas) {
        if (width == 0) return
        val now = SystemClock.uptimeMillis()

        if (status.isNotEmpty()) {
            pill(c, status, 16 * d, 48 * d, Color.parseColor("#CC000000"), 16 * d)
            return
        }

        if (frameW > 0) {
            // todos os objetos: contorno fino
            for (dt in dets) {
                val r = toScreen(dt.box)
                c.drawRoundRect(r, 10 * d, 10 * d, thin)
            }
            // objeto apontado: contorno forte + tag
            hover?.let { h ->
                val r = toScreen(h.box)
                c.drawRoundRect(r, 12 * d, 12 * d, hoverFill)
                c.drawRoundRect(r, 12 * d, 12 * d, hoverStroke)
                val tagH = 16 * d + 18 * d
                val ty = if (r.top - tagH - 6 * d > 0) r.top - tagH - 6 * d else r.top + 8 * d
                pill(c, "${Labels.name(h.label)}  ${pct(h.score)}", r.left, ty,
                    Color.parseColor("#E600A152"), 18 * d)
            }
            // objeto clicado: contorno laranja + cartão
            val sel = selected
            if (sel != null && now < selectedUntil) {
                c.drawRoundRect(toScreen(sel.box), 12 * d, 12 * d, selStroke)
                val ch = 96 * d
                val top = height - ch - 48 * d
                fill.color = Color.parseColor("#EE212121")
                c.drawRoundRect(16 * d, top, width - 16 * d, top + ch, 20 * d, 20 * d, fill)
                tp.color = Color.WHITE; tp.textSize = 30 * d
                c.drawText(Labels.name(sel.label), 32 * d, top + 46 * d, tp)
                tp.color = Color.parseColor("#BBBBBB"); tp.textSize = 16 * d
                c.drawText("Confiança: ${pct(sel.score)}", 32 * d, top + 78 * d, tp)
            }
        }

        // cursor do dedo
        cursor?.let { p ->
            if (pinching) {
                fill.color = Color.parseColor("#FFAB00")
                c.drawCircle(p.x, p.y, 14 * d, fill)
            } else {
                fill.color = Color.parseColor("#00E676")
                c.drawCircle(p.x, p.y, 5 * d, fill)
            }
            c.drawCircle(p.x, p.y, 16 * d, ring)
        } ?: run {
            if (selected == null || now >= selectedUntil) {
                pill(c, "Mostre a mão: aponte com o indicador, pinça = clique",
                    16 * d, height - 80 * d, Color.parseColor("#99000000"), 14 * d)
            }
        }
    }
}
